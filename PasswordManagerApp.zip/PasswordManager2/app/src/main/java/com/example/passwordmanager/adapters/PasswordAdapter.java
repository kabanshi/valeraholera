package com.example.passwordmanager.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.passwordmanager.R;
import com.example.passwordmanager.activities.PasswordDetailActivity;
import com.example.passwordmanager.database.DatabaseHelper;
import com.example.passwordmanager.models.PasswordItem;
import java.util.List;

public class PasswordAdapter extends RecyclerView.Adapter<PasswordAdapter.ViewHolder> {
    private List<PasswordItem> passwordItems;
    private Context context;
    private DatabaseHelper databaseHelper;

    public PasswordAdapter(List<PasswordItem> passwordItems, Context context, DatabaseHelper databaseHelper) {
        this.passwordItems = passwordItems;
        this.context = context;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_password, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PasswordItem item = passwordItems.get(position);
        holder.tvService.setText(item.getService());
        holder.tvLogin.setText(item.getLogin());
        holder.tvPassword.setText("••••••••");

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PasswordDetailActivity.class);
            intent.putExtra("PASSWORD_ID", item.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return passwordItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvService, tvLogin, tvPassword;

        public ViewHolder(View itemView) {
            super(itemView);
            tvService = itemView.findViewById(R.id.tvService);
            tvLogin = itemView.findViewById(R.id.tvLogin);
            tvPassword = itemView.findViewById(R.id.tvPassword);
        }
    }
}
