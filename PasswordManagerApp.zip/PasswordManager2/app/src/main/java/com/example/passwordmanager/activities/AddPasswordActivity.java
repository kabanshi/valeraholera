package com.example.passwordmanager.activities;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.passwordmanager.R;
import com.example.passwordmanager.database.DatabaseHelper;

public class AddPasswordActivity extends AppCompatActivity {
    private EditText etService, etLogin, etPassword, etNotes;
    private TextView tvError;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_password);

        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            finish();
            return;
        }

        initViews();
        setupPasswordToggle();
    }

    private void initViews() {
        etService = findViewById(R.id.etService);
        etLogin = findViewById(R.id.etLogin);
        etPassword = findViewById(R.id.etPassword);
        etNotes = findViewById(R.id.etNotes);
        tvError = findViewById(R.id.tvError);

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> savePassword());
    }

    private void setupPasswordToggle() {
        CheckBox cbShowPassword = findViewById(R.id.cbShowPassword);
        cbShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                etPassword.setTransformationMethod(null);
            } else {
                etPassword.setTransformationMethod(new PasswordTransformationMethod());
            }
            etPassword.setSelection(etPassword.getText().length());
        });
    }

    private void savePassword() {
        String service = etService.getText().toString().trim();
        String login = etLogin.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String notes = etNotes.getText().toString().trim();

        if (!validateInputs(service, login, password)) {
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        try {
            boolean success = dbHelper.addPassword(userId, service, login, password, notes);
            if (success) {
                Toast.makeText(this, "Пароль сохранён", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                tvError.setText("Ошибка при сохранении");
            }
        } finally {
            dbHelper.close();
        }
    }

    private boolean validateInputs(String service, String login, String password) {
        if (service.isEmpty()) {
            tvError.setText("Введите название сервиса");
            return false;
        }
        if (login.isEmpty()) {
            tvError.setText("Введите логин");
            return false;
        }
        if (password.isEmpty()) {
            tvError.setText("Введите пароль");
            return false;
        }
        return true;
    }
}