package com.example.passwordmanager.activities;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.passwordmanager.R;
import com.example.passwordmanager.database.DatabaseHelper;
import com.example.passwordmanager.models.PasswordItem;

public class PasswordDetailActivity extends AppCompatActivity {
    private TextView tvService, tvLogin, tvPassword, tvNotes;
    private CheckBox cbShowPassword;
    private Button btnDelete;
    private PasswordItem passwordItem;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_detail);

        databaseHelper = new DatabaseHelper(this);
        int passwordId = getIntent().getIntExtra("PASSWORD_ID", -1);
        passwordItem = databaseHelper.getPassword(passwordId);

        tvService = findViewById(R.id.tvService);
        tvLogin = findViewById(R.id.tvLogin);
        tvPassword = findViewById(R.id.tvPassword);
        tvNotes = findViewById(R.id.tvNotes);
        cbShowPassword = findViewById(R.id.cbShowPassword);
        btnDelete = findViewById(R.id.btnDelete);

        displayPasswordDetails();

        cbShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                try {
                    String decryptedPassword = databaseHelper.decrypt(passwordItem.getEncryptedPassword());
                    tvPassword.setText(decryptedPassword);
                } catch (Exception e) {
                    e.printStackTrace();
                    tvPassword.setText("Ошибка дешифрования");
                }
            } else {
                tvPassword.setText("••••••••");
            }
        });

        btnDelete.setOnClickListener(v -> deletePassword());
    }

    private void displayPasswordDetails() {
        if (passwordItem != null) {
            tvService.setText(passwordItem.getService());
            tvLogin.setText("Логин: " + passwordItem.getLogin());
            tvPassword.setText("••••••••");

            if (passwordItem.getNotes() != null && !passwordItem.getNotes().isEmpty()) {
                tvNotes.setText("Заметки: " + passwordItem.getNotes());
            } else {
                tvNotes.setText("Заметки отсутствуют");
            }
        }
    }

    private void deletePassword() {
        if (passwordItem != null) {
            boolean isDeleted = databaseHelper.deletePassword(passwordItem.getId());
            if (isDeleted) {
                Toast.makeText(this, "Пароль удален", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Ошибка при удалении", Toast.LENGTH_SHORT).show();
            }
        }
    }
}