package com.example.passwordmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.passwordmanager.R;
import com.example.passwordmanager.adapters.PasswordAdapter;
import com.example.passwordmanager.database.DatabaseHelper;
import com.example.passwordmanager.models.PasswordItem;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView tvWelcome;
    private RecyclerView rvPasswords;
    private DatabaseHelper databaseHelper;
    private String username;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("USERNAME");
        userId = getUserId(username);

        tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText("Добро пожаловать, " + username + "!");

        Button btnAddPassword = findViewById(R.id.btnAddPassword);
        btnAddPassword.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddPasswordActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        rvPasswords = findViewById(R.id.rvPasswords);
        rvPasswords.setLayoutManager(new LinearLayoutManager(this));
        loadPasswords();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPasswords();
    }

    private int getUserId(String username) {
        return databaseHelper.getUserId(username);
    }

    private void loadPasswords() {
        List<PasswordItem> passwordItems = databaseHelper.getAllPasswords(userId);
        PasswordAdapter adapter = new PasswordAdapter(passwordItems, this, databaseHelper);
        rvPasswords.setAdapter(adapter);
    }
}