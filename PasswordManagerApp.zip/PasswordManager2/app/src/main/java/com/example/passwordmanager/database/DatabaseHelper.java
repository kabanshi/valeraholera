package com.example.passwordmanager.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import com.example.passwordmanager.models.PasswordItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "PasswordManager.db";
    private static final int DATABASE_VERSION = 2;


    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";


    private static final String TABLE_PASSWORDS = "passwords";
    private static final String COLUMN_PASSWORD_ID = "password_id";
    private static final String COLUMN_SERVICE = "service";
    private static final String COLUMN_LOGIN = "login";
    private static final String COLUMN_ENCRYPTED_PASSWORD = "encrypted_password";
    private static final String COLUMN_NOTES = "notes";
    private static final String COLUMN_USER_ID_FK = "user_id_fk";


    private static final String ENCRYPTION_KEY = "MySuperSecretKey16";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_PASSWORDS_TABLE = "CREATE TABLE " + TABLE_PASSWORDS + "("
                + COLUMN_PASSWORD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_SERVICE + " TEXT,"
                + COLUMN_LOGIN + " TEXT,"
                + COLUMN_ENCRYPTED_PASSWORD + " TEXT,"
                + COLUMN_NOTES + " TEXT,"
                + COLUMN_USER_ID_FK + " INTEGER,"
                + "FOREIGN KEY(" + COLUMN_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")" + ")";
        db.execSQL(CREATE_PASSWORDS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PASSWORDS);
        onCreate(db);
    }




    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }


    public boolean checkUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }


    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }


    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            return id;
        }
        cursor.close();
        return -1;
    }




    public boolean addPassword(int userId, String service, String login, String password, String notes) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            String encrypted = encrypt(password);

            ContentValues values = new ContentValues();
            values.put(COLUMN_SERVICE, service);
            values.put(COLUMN_LOGIN, login);
            values.put(COLUMN_ENCRYPTED_PASSWORD, encrypted);
            values.put(COLUMN_NOTES, notes);
            values.put(COLUMN_USER_ID_FK, userId);

            long result = db.insert(TABLE_PASSWORDS, null, values);
            return result != -1;
        } catch (Exception e) {
            Log.e("DB_ERROR", "Encryption failed", e);
            return false;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }


    public List<PasswordItem> getAllPasswords(int userId) {
        List<PasswordItem> passwordList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PASSWORDS,
                new String[]{COLUMN_PASSWORD_ID, COLUMN_SERVICE, COLUMN_LOGIN, COLUMN_ENCRYPTED_PASSWORD, COLUMN_NOTES},
                COLUMN_USER_ID_FK + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COLUMN_SERVICE + " ASC");

        if (cursor.moveToFirst()) {
            do {
                PasswordItem item = new PasswordItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4));
                passwordList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return passwordList;
    }


    public PasswordItem getPassword(int passwordId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PASSWORDS,
                new String[]{COLUMN_PASSWORD_ID, COLUMN_SERVICE, COLUMN_LOGIN, COLUMN_ENCRYPTED_PASSWORD, COLUMN_NOTES},
                COLUMN_PASSWORD_ID + "=?",
                new String[]{String.valueOf(passwordId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            PasswordItem item = new PasswordItem(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4));
            cursor.close();
            return item;
        }
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }


    public boolean deletePassword(int passwordId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_PASSWORDS, COLUMN_PASSWORD_ID + "=?", new String[]{String.valueOf(passwordId)}) > 0;
    }


    public List<PasswordItem> searchPasswords(int userId, String query) {
        List<PasswordItem> passwordList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PASSWORDS,
                new String[]{COLUMN_PASSWORD_ID, COLUMN_SERVICE, COLUMN_LOGIN, COLUMN_ENCRYPTED_PASSWORD, COLUMN_NOTES},
                COLUMN_USER_ID_FK + "=? AND " + COLUMN_SERVICE + " LIKE ?",
                new String[]{String.valueOf(userId), "%" + query + "%"},
                null, null, COLUMN_SERVICE + " ASC");

        if (cursor.moveToFirst()) {
            do {
                PasswordItem item = new PasswordItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4));
                passwordList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return passwordList;
    }


    private String encrypt(String value) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedByteValue = cipher.doFinal(value.getBytes("utf-8"));
        return Base64.encodeToString(encryptedByteValue, Base64.DEFAULT);
    }


    public String decrypt(String value) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedValue64 = Base64.decode(value, Base64.DEFAULT);
        byte[] decryptedByteValue = cipher.doFinal(decryptedValue64);
        return new String(decryptedByteValue, "utf-8");
    }


    private Key generateKey() throws Exception {
        byte[] keyBytes = Arrays.copyOf(ENCRYPTION_KEY.getBytes("utf-8"), 16);
        return new SecretKeySpec(keyBytes, "AES");
    }


    @Override
    public synchronized void close() {
        super.close();
    }
}
