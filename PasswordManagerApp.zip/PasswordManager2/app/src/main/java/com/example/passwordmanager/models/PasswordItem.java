package com.example.passwordmanager.models;

public class PasswordItem {
    private int id;
    private String service;
    private String login;
    private String encryptedPassword;
    private String notes;

    public PasswordItem(int id, String service, String login, String encryptedPassword, String notes) {
        this.id = id;
        this.service = service;
        this.login = login;
        this.encryptedPassword = encryptedPassword;
        this.notes = notes;
    }


    public int getId() { return id; }
    public String getService() { return service; }
    public String getLogin() { return login; }
    public String getEncryptedPassword() { return encryptedPassword; }
    public String getNotes() { return notes; }
}