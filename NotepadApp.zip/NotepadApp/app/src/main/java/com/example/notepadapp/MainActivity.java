package com.example.notepadapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView notesListView;
    private DatabaseHelper db;
    private TextView selectedNoteTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        notesListView = findViewById(R.id.notesListView);
        selectedNoteTextView = findViewById(R.id.selectedNoteTextView);

        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button aboutButton = findViewById(R.id.aboutButton);
        Button exitButton = findViewById(R.id.exitButton);

        loadNotes();

        notesListView.setOnItemClickListener((parent, view, position, id) -> {
            Note note = (Note) parent.getItemAtPosition(position);
            selectedNoteTextView.setText(note.getContent());
        });

        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NotepadActivity.class);
            startActivity(intent);
        });

        deleteButton.setOnClickListener(v -> {
            if (notesListView.getCheckedItemPosition() != ListView.INVALID_POSITION) {
                Note note = (Note) notesListView.getItemAtPosition(notesListView.getCheckedItemPosition());
                db.deleteNote(note.getId());
                loadNotes();
                selectedNoteTextView.setText("(формируется по нажатию на конкретный элемент списка)");
                Toast.makeText(MainActivity.this, "Запись удалена", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Выберите запись для удаления", Toast.LENGTH_SHORT).show();
            }
        });

        aboutButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        exitButton.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void loadNotes() {
        List<Note> notes = db.getAllNotes();
        ArrayAdapter<Note> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_single_choice, notes);
        notesListView.setAdapter(adapter);
        notesListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
    }
}